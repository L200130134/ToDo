package logictest

fun main() {
    printLeap(1900, 2020)
}

fun printLeap(yearFrom: Int, yearTo: Int) {
    val step = 4
    for (i in yearFrom until yearTo+1 step step) {
        if (i + step <= yearTo) {
            print("$i, ")
        } else {
            print("$i")
        }
    }
}