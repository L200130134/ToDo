package logictest

import java.lang.Math.ceil

fun main() {
    val words = "Ibu Ratna antar ubi"
    println("Is palindrome : ${isPalindromeArray(words)}")
}

fun isPalindromeArray(words: String): Boolean {
    val arr = words.toCharArray()
    val length = arr.size
    val mid = ceil((length / 2f).toDouble()).toInt()

    var result = true

    for (i in 0 until mid) {
        val lastIndex = length - i - 1
        if (arr[i].toLowerCase() != arr[lastIndex].toLowerCase()) {
            result = false
        }
    }

    return result
}