package logictest

fun main() {
    val arr = arrayOf(15, 1, 3)
    println("Nearest fibo : ${printNearestFibo(arr)}")
}

fun printNearestFibo(arr: Array<Int>) : Int? {
    val sum = arr.sum()
    val n = sum
    val fib = LongArray(n)

    for (i in 0 until n) {
        var value: Long
        if (i < 2) {
            value = i.toLong()
        } else {
            value = fib[i - 1] + fib[i - 2]
        }
        if (value > sum) {
            return (value - sum).toInt()
        } else {
            fib[i] = value
        }
    }
    return null
}