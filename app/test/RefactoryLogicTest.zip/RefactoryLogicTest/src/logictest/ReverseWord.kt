package logictest

fun main() {
    val words = "I am A Great human"
    println("Result : ${reverseWords(words)}")
}

fun reverseWords(value: String) : String {
    val result = StringBuilder()
    val splitString = value.split(" ")
    val arrSize = splitString.size

    for (i in splitString.indices) {
        val word = splitString[i]
        val reverse = reverseWord(word)
        result.append(reverse)
        if (i < arrSize - 1) {
            result.append(" ")
        }
    }

    return result.toString()
}

fun reverseWord(value: String): String {
    val result = StringBuilder()
    val arr = value.toCharArray()
    val arrSize = arr.size

    for (i in arrSize-1 downTo 0) {
        val char = arr[i]
        val lastIndex = arrSize - i - 1
        if (arr[lastIndex].isUpperCase()) {
            result.append(char.toUpperCase())
        } else {
            result.append(char.toLowerCase())
        }
    }

    return result.toString()
}
