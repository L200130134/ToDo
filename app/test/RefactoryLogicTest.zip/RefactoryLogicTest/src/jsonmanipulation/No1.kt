package jsonmanipulation

import jsonmanipulation.parser.JsonParser
import org.json.JSONArray

fun main() {
    val result = findItemMeetingRoom()
    println("Result : $result \nTotal data : ${result?.length()}")
}

fun findItemMeetingRoom() : JSONArray? {
    val result = JSONArray()
    val jsonArray = JsonParser.getJsonFromResources("data.json")
    if (jsonArray != null) {
        val length = jsonArray.length()
        for (i in 0 until length) {
            val jsonObject = jsonArray.getJSONObject(i)
            val placementField = jsonObject?.getJSONObject("placement")
            if ("Meeting Room" == placementField?.get("name")) {
                result.put(jsonObject)
            }
        }
    }
    return result
}