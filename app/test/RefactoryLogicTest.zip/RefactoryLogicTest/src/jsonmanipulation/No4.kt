package jsonmanipulation

import jsonmanipulation.parser.JsonParser
import org.json.JSONArray
import java.text.DateFormat
import java.util.*
import java.util.Locale.*

fun main() {
    val result = findPurchasedAt(16, 1, 2020)
    println("Result : $result \nTotal data : ${result?.length()}")
}

fun findPurchasedAt(d: Int = 0, m: Int = 0, y: Int = 0) : JSONArray? {
    val result = JSONArray()
    val jsonArray = JsonParser.getJsonFromResources("data.json")
    if (jsonArray != null) {
        val length = jsonArray.length()
        for (i in 0 until length) {
            val jsonObject = jsonArray.getJSONObject(i)
            val purchasedField = jsonObject?.get("purchased_at")
            if (purchasedField is Number) {
                val calendar = getCalendar(purchasedField.toLong() * 1000)
                if (d == calendar[Calendar.DAY_OF_MONTH] &&
                    m == calendar[Calendar.MONTH] + 1 &&
                    y == calendar[Calendar.YEAR]) {
                    result.put(jsonObject)
                }
            }
        }
    }
    return result
}

fun getCalendar(time: Long): Calendar {
    val calendar = Calendar.getInstance(getDefault())
    calendar.timeInMillis = time
    return calendar
}
