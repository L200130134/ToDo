package jsonmanipulation

import jsonmanipulation.parser.JsonParser
import org.json.JSONArray
import java.text.DateFormat
import java.util.*
import java.util.Locale.*

fun main() {
    val result = findBrownColor()
    println("Result : $result \nTotal data : ${result?.length()}")
}

fun findBrownColor() : JSONArray? {
    val result = JSONArray()
    val jsonArray = JsonParser.getJsonFromResources("data.json")
    if (jsonArray != null) {
        val length = jsonArray.length()
        for (i in 0 until length) {
            val jsonObject = jsonArray.getJSONObject(i)
            val tagsField = jsonObject?.getJSONArray("tags")
            if (tagsField != null) {
                val tagLength = tagsField.length()
                Tag@ for (t in 0 until tagLength) {
                    val tag = tagsField.get(t)
                    if ("brown" == tag) {
                        result.put(jsonObject)
                        break@Tag
                    }
                }
            }
        }
    }
    return result
}