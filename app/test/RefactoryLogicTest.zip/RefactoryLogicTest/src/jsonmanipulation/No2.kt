package jsonmanipulation

import jsonmanipulation.parser.JsonParser
import org.json.JSONArray

fun main() {
    val result = findElectronicDevices()
    println("Result : $result \nTotal data : ${result?.length()}")
}

fun findElectronicDevices() : JSONArray? {
    val result = JSONArray()
    val jsonArray = JsonParser.getJsonFromResources("data.json")
    if (jsonArray != null) {
        val length = jsonArray.length()
        for (i in 0 until length) {
            val jsonObject = jsonArray.getJSONObject(i)
            val typeField = jsonObject?.get("type")
            if ("electronic" == typeField) {
                result.put(jsonObject)
            }
        }
    }
    return result
}