package jsonmanipulation.parser

import org.json.JSONArray
import java.io.IOException

class JsonParser {
    companion object {
        fun getJsonFromResources(name: String): JSONArray? {
            try {
                val text = this::class.java.classLoader.getResource(name)?.readText()
                if (text != null) {
                    return JSONArray(text)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }
    }
}